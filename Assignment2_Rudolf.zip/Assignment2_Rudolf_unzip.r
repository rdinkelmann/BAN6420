# Load required library
library(utils)

# Define the path of the zip file
zip_file <- "Employee Profile.zip"

# Unzip the file
unzip(zip_file, exdir = "unzipped_employee")

# Read and display the employee data
csv_file <- list.files("unzipped_employee", pattern = "\\.csv$", full.names = TRUE)

if (length(csv_file) > 0) {
    employee_data <- read.csv(csv_file[1], stringsAsFactors = FALSE)
    print(employee_data) # Display the contents of the CSV file
} else {
    cat("No CSV file found in the unzipped folder.\n")
}
