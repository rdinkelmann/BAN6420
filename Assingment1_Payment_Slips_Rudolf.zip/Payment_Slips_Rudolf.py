import random as r

#Create an empty list to store employee details
Employee_payslip_list= {}

#Gender list to be used during random gender selection
Gender_list = ["Male", "Female"]

#Create a list of 400 employees with payslip attributes
for employee in range(1,401,1):
    try:
        salary = r.randint(5000, 30000)
        gender = r.choice(Gender_list)
        age = r.randint(18, 65)
    #Conditions used to classify employee level
        if salary > 10000 and salary < 20000:
            Employee_level = "A1"
        elif salary > 7500 and salary < 30000 and gender == "Female":
            Employee_level = "A5-F"
        else:
            Employee_level = "Unknown"
    #Adding keys and values to the employee payslip list
        Employee_payslip_list[employee] = {"Salary": salary, "Gender": gender, "Age": age, "Employee Level": Employee_level}
    #Used to handle exception during the random creation process
    except Exception as exc:
        print(f"Error creating {employee}: {exc}")

    #Printing all employees in the list for verificaiton purposes
for i in range(1,len(Employee_payslip_list) + 1, 1):
    Emp_value = Employee_payslip_list[i]
    print(f"Employee ID = {i}, Salary = {Emp_value['Salary']}, Gender = {Emp_value['Gender']}, Age = {Emp_value['Age']}, Employee Level = {Emp_value['Employee Level']}")
