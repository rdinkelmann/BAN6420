set.seed(123) 
# Create an empty list to store employee details
Employee_payslip_list <- list()

# Gender list to be used during random gender selection
Gender_list <- c("Male", "Female")

# Create a list of 400 employees with payslip attributes
for (employee in 1:400) {
  tryCatch({
    # Randomly generate salary, gender, and age
    salary <- sample(5000:30000, 1)  # Random salary between 5000 and 30000
    gender <- sample(Gender_list, 1)  # Random gender selection
    age <- sample(18:65, 1)          # Random age between 18 and 65

    # Conditions used to classify employee level
    if (salary > 10000 & salary < 20000) {
      Employee_level <- "A1"
    } else if (salary > 7500 & salary < 30000 & gender == "Female") {
      Employee_level <- "A5-F"
    } else {
      Employee_level <- "Unknown"
    }

    # Adding keys and values to the employee payslip list
    Employee_payslip_list[[employee]] <- list(Salary = salary, Gender = gender, Age = age, Employee_Level = Employee_level)
  }, error = function(e) {
    message(paste("Error creating employee", employee, ":", e$message))
  })
}

# Printing all employees in the list for verification purposes
for (i in 1:length(Employee_payslip_list)) {
  Emp_value <- Employee_payslip_list[[i]]
  cat(paste("Employee ID =", i, 
            ", Salary =", Emp_value$Salary, 
            ", Gender =", Emp_value$Gender, 
            ", Age =", Emp_value$Age, 
            ", Employee Level =", Emp_value$Employee_Level, "\n"))
}