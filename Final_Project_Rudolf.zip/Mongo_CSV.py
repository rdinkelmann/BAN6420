from pymongo import MongoClient
import csv

#Initialising the mongoDB conneciton as provided in the cluster and connect to MongoDB Compass on my local PC
cluster = MongoClient("mongodb://localhost:27017")  
#cluster = MongoClient("mongodb+srv://baas:1234@cluster0.ftqsy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0") #To be used when port 27017 is opened on my PC

#Set up the DB and collection method 
db = cluster["db_test"]  #Connect to the db_test database
collection = db["users"]  #Connect to the users collection in db_test

mongo_data = collection.find({}) #Using find instead of fine_one() to retreive all entries
mongo_list = list(mongo_data) #convert into a list
#Create an empty list
list_user = []

#Create an object class
class User:
    def __init__(self, Age, Gender, Total_Income, Utilities, Entertainment, Shopping, SchoolFees, Healthcare):
        self.Age = Age
        self.Gender = Gender
        self.Total_Income = Total_Income
        self.Utilities = Utilities
        self.Entertainment = Entertainment
        self.Shopping = Shopping
        self.SchoolFees = SchoolFees
        self.Healthcare = Healthcare
#Need to converto to object to a dictionary
    def to_dict(self):
        return {"Age": self.Age,"Gender": self.Gender,"Total_Income": self.Total_Income,"Utilities": self.Utilities,"Entertainment": self.Entertainment,"Shopping": self.Shopping,"SchoolFees": self.SchoolFees,"Healthcare": self.Healthcare,}

#Loop through the mongo list with a for loop
for i in mongo_list:
    #check if expenses dictionary exists
    expenses = i.get("Expenses", {})
    #Retreive all the indivisual entries
    Age = i.get("Age")
    Gender = i.get("Gender")
    Total_Income = i.get("Total_Income")
    Utilities = expenses.get("Utilities")
    Entertainment = expenses.get("Entertainment")
    Shopping = expenses.get("Shopping")
    SchoolFees = expenses.get("SchoolFees")
    Healthcare = expenses.get("Healthcare")
    #print(Age, Utilities, SchoolFees)
    user_ind = User(Age, Gender, Total_Income, Utilities, Entertainment, Shopping, SchoolFees, Healthcare)
    list_user.append(user_ind)
    #print(user_ind.to_dict())  

#Write the data store as a dictionary in a CSV file using the CSV module, newline will prevent empty rows
with open("healthcare_data.csv", mode="w", newline="") as csv_file:
    #Setting up the headings of each column
    fieldnames = ["Age", "Gender", "Total_Income", "Utilities", "Entertainment", "Shopping", "SchoolFees", "Healthcare"]
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    writer.writeheader()
    #Loop through the rows to write them in the CSV file
    for i in list_user:
        writer.writerow(i.to_dict()) 
