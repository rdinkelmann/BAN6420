#Policyholder class to handle registration, suspension, and reactivation of policyholders.
class Policyholder:
    def __init__(self, first_name, last_name, job_title, emp_id, policy_id, status=None):
        self.first_name = first_name
        self.last_name = last_name
        self.job_title = job_title
        self.emp_id = emp_id
        self.policy_id = policy_id
        self.status = status

    #Method to register the policyholder as active
    def register(self):
        self.status = "Active Policy"

    #Method to suspend the policyholder’s policy
    def suspend(self):
        self.status = "Suspended Policy"

    #Method to reactivate the policyholder’s policy
    def reactivate(self):
        self.status = "Reactivated Policy"

    #Method to display the policyholder’s details and their policy status
    def display_policy(self):
        print(f"{self.first_name} {self.last_name}, Policy Status: {self.status if self.status else 'No status has been assigned yet'}")
