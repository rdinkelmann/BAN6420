class Payment:
    def __init__(self, amount_due, status=None, penalty=0):
        self.amount_due = round(amount_due, 2)  
        self.status = status
        self.penalty = penalty

    #Method to process the payment and update the status
    def process_payment(self, amount_paid):
        amount_paid = round(amount_paid, 2)  
        if amount_paid >= self.amount_due:
            self.status = "Paid"
            self.amount_due = 0
            print(f"Paid {amount_paid}. Status: {self.status}")
        else:
            self.status = "Partial Payment"
            self.amount_due = round(self.amount_due - amount_paid, 2)  
            print(f"Paid {amount_paid}. Your remaining balance is {self.amount_due}")

    #Method to send a reminder if the payment is still pending
    def send_reminder(self):
        if self.status != "Paid":
            print(f"Reminder: You still owe us {self.amount_due}.")

    #Method to apply a penalty for late payments
    def apply_penalty(self):
        if self.status != "Paid":
            self.penalty = 50  #Fixed penalty
            self.amount_due = round(self.amount_due + self.penalty, 2)  
            print(f"Penalty of {self.penalty} added. Total balance: {self.amount_due}")

    #Method to display the current payment status
    def display_payment(self):
        print(f"Amount Due: {self.amount_due}, Status: {self.status}")
