#Importing the classes
from Assignment3_Rudolf_Payments import Payment
from Assignment3_Rudolf_Products import Product
from Assignment3_Rudolf_Policyholders import Policyholder

#Inputting text to create two policyholders with their info
policyholder_example1 = Policyholder("Baas", "Botha", "Civil Engineer", "E123", "P001")
policyholder_example2 = Policyholder("Janus", "Van Wyk", "Manager", "E456", "P002")

#Registering the two policyholders
policyholder_example1.register()
policyholder_example2.register()

#Showing the two policyholders
policyholder_example1.display_policy()
policyholder_example2.display_policy()

#Creating two new products
product1 = Product("Life Cover Policy", "PL1")
product2 = Product("Health Cover Policy", "PH1")

#Updating product details
product1.update_product("Life Cover Policy New", "PL01")

#Displaying the product details
product1.display_product()
product2.display_product()

#Making payments
payment1 = Payment(2211.6)
payment2 = Payment(4567.8)

#Processing payments
payment1.process_payment(2211.6)
payment2.process_payment(3500)  #Partial payment

#Sending payment reminders
payment1.send_reminder()
payment2.send_reminder()

#Applying penalties
payment2.apply_penalty()

#Showing payment status
payment1.display_payment()
payment2.display_payment()
