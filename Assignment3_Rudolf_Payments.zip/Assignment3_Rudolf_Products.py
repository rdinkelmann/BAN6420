#Product class to handle creating, updating, removing, and suspending products.
class Product:
    def __init__(self, name, product_id, status=None):
        self.name = name
        self.product_id = product_id
        self.status = status

    #Method to update the product details
    def update_product(self, new_name, new_id):
        self.name = new_name
        self.product_id = new_id
        print(f"Product has beenm updated: {self.name}, ID: {self.product_id}")

    #Method to remove the product from the system
    def remove_product(self):
        self.name = None
        self.product_id = None
        self.status = "Product has been Removed"
        print("This product has been removed from the system and does not exist.")

    #Method to suspend the product if needed
    def suspend_product(self):
        self.status = "Suspended"
        print(f"Product {self.name} has been suspended indefinitely.")

    #Method to display product details
    def display_product(self):
        print(f"{self.name}, Status: {self.status if self.status else 'No status has been assigned yet'}")
