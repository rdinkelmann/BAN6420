#Import the required packagees
import pandas as pd
import numpy as np
from sklearn import datasets 
from sklearn.decomposition import PCA
from sklearn import preprocessing
import matplotlib.pyplot as plt

#Load he cancer data from sklearn
cancer_data = datasets.load_breast_cancer(as_frame=True)
#Cpnvert the data to a dataframe
cancer_data_frame = cancer_data.frame
#Target column represents the outcome in binary terms if the tumor is benign(0) or malignant(1). Remove target column from the data
x_data = cancer_data_frame.drop(columns="target") 
#Seperate the target data as a standalone dataframe
target_data = cancer_data_frame["target"] 
#Scaling the data
x_data_scaled = preprocessing.scale(x_data)

pca = PCA()
pca.fit(x_data_scaled)
pca_data = pca.transform(x_data_scaled)
per_var = np.round(pca.explained_variance_ratio_*100, decimals=1)

#Plot the variance contribution of all the components in order to identify the top two components.
plt.figure(figsize=(10, 6))
plt.bar(range(1, len(per_var) + 1), per_var)
plt.xlabel('Components')
plt.ylabel('Explained Variance (%)')
plt.title('Explained Variance for all Components')
plt.show()
#By reviewing the plot, component 1 and 2 constitutes of approximately 65% of the variance and therefore selected as PC1 and PC2

#Create a scatter plot for the first two PCA components
pca_data_2d = pca_data[:, :2]
plt.figure(figsize=(8, 6))
plt.scatter(pca_data_2d[:, 0], pca_data_2d[:, 1], c=target_data, cmap='coolwarm', marker='.')
plt.xlabel('PC-1')
plt.ylabel('PC-2')
plt.title('PCA of Two Components')
plt.show()
#The blue points represnt benign tumors
#The red points represnt malignant tumors. 
#A clear seperation between these two colors in the scatter plot suggests that the first two principal components (PC1 and PC2) are highly effective in distinquishing between the two tumor types.
#Mean concave points and mean concavity contribute significantly to PC1

#Bonus Question
#All the variables will be considered as predictors to determine the target.
from sklearn.preprocessing import StandardScaler as sc
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report

#Need to normalize the data to make all variables uniformed for the analysis
#Create a scalar object 
scalar = sc() #brackets used to initialise the object
#Need to fit the data to the scalar and transform
X_scaled_log = scalar.fit_transform(x_data)
#Spit the data into a training and a testing part
x_train, x_test, y_train, y_test = train_test_split(X_scaled_log, target_data, test_size=0.25, random_state=42)
#Next is to Train the model
lr = LogisticRegression()
#Train te model now on the training data
lr.fit(x_train, y_train)
#predict the target variable based on the test data
y_prediction = lr.predict(x_test)
#Evaluation of the model
accuracy = accuracy_score(y_test, y_prediction)
print(f"Logistic Regression Accuracy: {accuracy}")
#The accuracy of the model is estimated as 97.9%
print(classification_report(y_test, y_prediction))
