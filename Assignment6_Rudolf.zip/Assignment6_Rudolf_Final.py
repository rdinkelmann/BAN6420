#Suppress TensorFlow logs
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import tensorflow as tf
from tensorflow import keras
from keras import datasets, layers, models
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.callbacks import ModelCheckpoint

#Load the dataset from keras
mnist_fashion = datasets.fashion_mnist.load_data()

#Split the dataset into training and test sets
(x_train, y_train), (x_test, y_test) = mnist_fashion

#Normalize and reshaping the data
x_train = x_train.reshape((60000, 28, 28, 1)) / 255.0
x_test = x_test.reshape((10000, 28, 28, 1)) / 255.0

#Create a functional API to be used on the model
#In this step I am creating a neural network model in Keras with 6 layers (3 CNN layers, 2 pooling layers, 1 flattening layer)
def CNN_builder():
    inputs = keras.Input(shape=(28, 28, 1), name="Input layer")
    x = layers.Conv2D(filters=32, kernel_size=3, strides=(1, 1), padding="valid", activation="relu", name="conv_layer_1")(inputs)
    x = layers.MaxPool2D(pool_size=2, name="pooling_1")(x)
    x = layers.Conv2D(filters=64, kernel_size=3, activation="relu", name="conv_layer_2")(x)
    x = layers.MaxPool2D(pool_size=2, name="pooling_2")(x)
    x = layers.Conv2D(filters=128, kernel_size=3, activation="relu", name="conv_layer_3")(x)
    x = layers.Flatten(name="flattening_layer")(x)

    outputs = layers.Dense(units=10, activation="softmax", name="output_layer")(x)
    model = keras.Model(inputs=inputs, outputs=outputs, name="CNN_mnsit_model")
    model.compile(optimizer="rmsprop", loss="sparse_categorical_crossentropy", metrics=["accuracy"]) 
    return model

model = CNN_builder()

#Model Summary
model.summary()

#Use the best model based on the checkpoint validation
modelcheckpoint = ModelCheckpoint(filepath="CNN_mnsit.keras", save_best_only=True, monitor="val_loss")
callback_list = [modelcheckpoint]

#In this step AI will be training the model and using test data as validation
history = model.fit(x=x_train, y=y_train, validation_data=(x_test, y_test), epochs=20, batch_size=128, callbacks=callback_list)

#In the next step, I will be testing the model
test_model = keras.models.load_model("CNN_mnsit.keras")
test_model.evaluate(x=x_test, y=y_test)

#Here i am performing the predictions for the first 2 images
predictions2 = test_model.predict(x_test[:2])

#Print out the predicted labels for the first 2 images
predicted_labels = np.argmax(predictions2, axis=1)
print("Here are the predicted labels for the first 2 images:", predicted_labels)

#To visualize the first 2 images along with their predictions
plt.figure(figsize=(8, 4))

for i in range(2):
    plt.imshow(x_test[i].reshape(28, 28), cmap='gray')
    plt.title(f"Predicted Classes: {predicted_labels[i]}")
    plt.show()

#The script will output the predicted labels for the first two images, which are pullover = 9 and ankle boot = 2.
