import csv
import os as o
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

csv_list = []
#Step 1 is to rename the file
#First check if the file exists
filepath = r'C:\Users\dinkelmann\Desktop\Rudolf\Nexford\BAN6420\Assignment 4\netflix_data.csv'
new_filepath = r'C:\Users\dinkelmann\Desktop\Rudolf\Nexford\BAN6420\Assignment 4\Netflix_shows_movies.csv'
if o.path.exists(filepath) is True:
    o.rename(filepath, new_filepath)
    print("File has been renamed")
elif o.path.exists(new_filepath):
    print("New file already exists")
else:
    print("File doesn't exist")

#used 2 mothods to read to csv to practive, can also use pandas
#csv_df = pd.read_csv(new_filepath, encoding='utf-8')
with open('Netflix_shows_movies.csv', 'r', encoding='utf-8') as csv_file:
    csv_reader = csv.reader(csv_file)
    header_row = next(csv_reader)

    for line in csv_reader:
        for i in range(len(line)):
            if line[i] == "": #Step 2 is tho handle the missing values
                line[i] = pd.NA
        csv_list.append(line)
#print(csv_list)

#Convert list into a dataframe
csv_df = pd.DataFrame(csv_list, columns=header_row)

#Step 3 is to perform data exploration tasks
Description = csv_df.describe() #Checking the row count, number of unique rows
Data_Types = csv_df.dtypes #Checking the data types that are used in each column
csv_df["release_year"] = pd.to_numeric(csv_df["release_year"]) #Convert release year to numeric
release_year_f = csv_df["release_year"].value_counts() #Check how many times a movie or tv show was released in each year. Release date 2018 was most common
ratings_f = csv_df["rating"].value_counts() #Check for the most common ratings 
genre_u = csv_df["listed_in"].str.split(",").explode().unique() #Check for the different types of genres
genre_mode = csv_df["listed_in"].str.split(",").explode().mode() #Check the mode of the listed genres
missing_values = csv_df.isnull().sum() #Chekc for the number of missing values per column


#Step 4 is to create visualizations for most watched genres and ratings distribution
#Top genres plot
genre_types = csv_df["listed_in"].str.split(",").explode().value_counts().head(10)
plt.figure(figsize=(12, 8)) 
sns.barplot(x=genre_types.index, y=genre_types.values, palette='coolwarm', hue=genre_types.index, legend=False)
plt.title("Top 10 Netflix Genres")
plt.xlabel("Genres")
plt.ylabel("Frequency")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
#plt.show()
#Distrubution of ratings
rating_types = csv_df["rating"].value_counts()
plt.figure(figsize=(12, 8))
sns.countplot(x=csv_df['rating'], palette='coolwarm', order=rating_types.index)
plt.title("Distribution of Movie/TV Shows Ratings")
plt.xlabel("Rating")
plt.ylabel("Frequency")
plt.xticks(rotation=45, ha='right', fontsize=10)
plt.tight_layout()
plt.show()