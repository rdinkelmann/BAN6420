#Load necessary libraries
library(ggplot2)
library(dplyr)
library(readr)

#Step 1 Load the Data from the CSV file
csv_df <- read_csv("C:/Users/dinkelmann/Desktop/Rudolf/Nexford/BAN6420/Assignment 4/Netflix_shows_movies.csv")

#Step 2 Clean the Data
#Replace empty strings with NA
csv_df[csv_df == ""] <- NA

#Step 3 Generate the Top 10 Genres
#Split the genres and get the top 10 most popular
genre_list <- unlist(strsplit(csv_df$listed_in, ","))
genre_table <- table(genre_list)
top_genres <- sort(genre_table, decreasing = TRUE)[1:10]

#Step 4 Create the Bar Plot for Top 10 Genres
ggplot(data = as.data.frame(top_genres), aes(x = reorder(genre_list, -Freq), y = Freq)) +
  geom_bar(stat = "identity", fill = "lightblue") +
  labs(title = "Top 10 Netflix Genres", x = "Genres", y = "Frequency") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
